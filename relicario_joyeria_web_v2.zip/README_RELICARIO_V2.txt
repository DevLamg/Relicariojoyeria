RELICARIO JOYERÍA — V2

CAMBIAR WHATSAPP:
Busca "const CONFIG" en el HTML y cambia:
whatsapp: "584120000000"
por el número real, sin +, espacios ni guiones.

CAMBIAR PRECIOS:
Busca "const PRICES".
Ejemplo:
"01": "$350"
"02": "$420"
Si queda vacío, aparece "Consultar precio".

CAMBIAR TEXTOS:
Puedes abrir el HTML con VS Code, Notepad++ o incluso Bloc de notas.
Usa Ctrl+F para buscar el texto y reemplazarlo.

CAMBIAR PRODUCTOS:
Busca "const PRODUCTS". Cada producto tiene nombre, categoría,
material, descripción e imagen.

CAMBIAR FOTOS:
La V2 conserva las fotos incrustadas para que funcione como un único HTML.
Para cambiar una foto manualmente hay que sustituir el valor de "image"
del producto. La versión ideal para WordPress/Elementor será convertir
estas imágenes en archivos administrables desde WordPress.

CORRECCIONES:
- Header WhatsApp ahora tiene fondo dorado y texto/icono visible.
- Botón flotante ahora tiene icono real de WhatsApp en SVG.
